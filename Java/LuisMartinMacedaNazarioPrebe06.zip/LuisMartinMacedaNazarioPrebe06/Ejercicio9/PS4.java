		

		public class PS4 extends Consola{
		/**Metodo para encender de la clase PS4
		*/
		public void encender(){
			System.out.println("PS4 Encendida");
		}
		/**Metodo para apagar de la clase PS4
		*/
 		public void apagar(){
 			System.out.println("PS4 Apagada");
 		}
 		/**Metodo para mostrar graficos de la clase PS4
		*/
 		public void estadoGraficos(){
 			System.out.println("1080p 30fps");
 		}
 		/**Metodo para mostrar hardware de la clase PS4
		*/
 		public void hardware(){
 			System.out.println(" ");
 		}
}
