
public class PC extends Consola{
		/**Metodo para encender de la clase PC
		*/
		public void encender(){
			System.out.println("PC Encendida");
		}
		/**Metodo para apagar de la clase PC
		*/
 		public void apagar(){
 			System.out.println("PC Apagada");
 		}
 		/**Metodo para mostrar Graficos de la clase PC
		*/
 		public void estadoGraficos(){
 			System.out.println("1080p 60fps");
 		}
 		/**Metodo para mostrar hardware de la clase PC
		*/
 		public void hardware(){
 			System.out.println(" ");
 		}
}
