
		public class Consola{
		/**Metodo para encender de la clase Consola
		*/
		public void encender(){
			System.out.println("Consola Encendida");
		}
		/**Metodo para apagar de la clase Consola
		*/
 		public void apagar(){
 			System.out.println("Consola Apagada");
 		}
 		/**Metodo para mostrar graficos de la clase Consola
		*/
 		public void estadoGraficos(){
 			System.out.println("1080p 60fps");
 		}
 		/**Metodo para mostrar hardware de la clase Consola
		*/
 		public void hardware(){
 			System.out.println(" ");
 		}
}
