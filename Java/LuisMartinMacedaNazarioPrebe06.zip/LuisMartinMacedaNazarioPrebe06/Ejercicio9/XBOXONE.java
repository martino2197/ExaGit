

public class XBOXONE extends Consola{
		/**Metodo para encender de la clase XBOXONE
		*/
		public void encender(){
			System.out.println("XBOXONE Encendida");
		}
		/**Metodo para apagar de la clase XBOXONE
		*/
 		public void apagar(){
 			System.out.println("XBOXONE Apagada");
 		}
 		/**Metodo para mostrar graficos de la clase XBOXONE
		*/
 		public void estadoGraficos(){
 			System.out.println("900p 30fps");
 		}
 		/**Metodo para mostrar hardware de la clase XBOXONE
		*/
 		public void hardware(){
 			System.out.println(" ");
 		}
}
