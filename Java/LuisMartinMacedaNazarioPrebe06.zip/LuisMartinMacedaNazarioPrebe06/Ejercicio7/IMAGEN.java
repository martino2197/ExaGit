
public class IMAGEN implements Reproduccion {
		/**metodo implementado play para la clase IMAGEN
 		*/
		public void play(){
			System.out.println("Visualizando Imagen");
		}
		/**metodo implementado siguiente para la clase IMAGEN
 		*/
 		public void siguiente(){
 			System.out.println("Imagen Siguiente");
 		}
 		/**metodo implementado anterior para la clase IMAGEN
 		*/
 		public void anterior(){
 			System.out.println("Imagen Anterior");
 		}
 		/**metodo implementado pausa para la clase IMAGEN
 		*/
 		public void pausa(){
 			System.out.println("Funcion No valida");
 		}
}
