

public class MP3 implements Reproduccion {
		/**metodo implementado play para la clase MP3
 		*/
		public void play(){
			System.out.println("Reproduciendo Cancion");
		}
 		/**metodo implementado siguiente para la clase MP3
 		*/
 		public void siguiente(){
 			System.out.println("Reproduciendo Cancion Siguiente");
 		}
 		/**metodo implementado anterior para la clase MP3
 		*/
 		public void anterior(){
 			System.out.println("Reproduciendo Cancion Anterior");
 		}
 		/**metodo implementado pausa para la clase MP3
 		*/
 		public void pausa(){
 			System.out.println("Cancion En Pausa");
 		}
}
