

public class VIDEO implements Reproduccion {
		/**metodo implementado play para la clase VIDEO
 		*/
		public void play(){
			System.out.println("Reproduciendo Video");
		}
 		/**metodo implementado siguiente para la clase VIDEO
 		*/
 		public void siguiente(){
 			System.out.println("Reproduciendo Video Siguiente");
 		}
 		/**metodo implementado anterior para la clase VIDEO
 		*/
 		public void anterior(){
 			System.out.println("Reproduciendo Video Anterior");
 		}
 		/**metodo implementado pausa para la clase VIDEO
 		*/
 		public void pausa(){
 			System.out.println("Video En pausa");
 		}
}
