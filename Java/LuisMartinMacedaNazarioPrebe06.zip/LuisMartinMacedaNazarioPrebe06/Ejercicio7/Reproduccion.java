/*Interfaz con el objetivo de ser utilizada en aplicaciones multimedia de musica, fotos y video
 */

 public interface Reproduccion{
 		/**metodo abstracto play
 		*/
 		public void play(); //los metodos de una interfaz siempre son publicos y abstractos
 		/**metodo abstracto siguiente
 		*/
 		public void siguiente(); //los metodos de una interfaz siempre son publicos y abstractos
 		/**metodo abstracto anterior
 		*/
 		public void anterior(); //los metodos de una interfaz siempre son publicos y abstractos
 		/**metodo abstracto pausa
 		*/
 		public void pausa(); //los metodos de una interfaz siempre son publicos y abstractos
 }

